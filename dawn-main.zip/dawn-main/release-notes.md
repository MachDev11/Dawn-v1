Dawn 15.1.0 changes the way SVGs are rendered
### Fixes and improvements
- Moves SVGs from Liquid snippets to `.svg` files in the `/assets` folder
- Uses new `inline_asset_content` Liquid filter to render SVGs
